# Shared download reconstruction — validation pending

This is a reconstruction, not recovery of the historical shared-download workspace.
The historical signing private key and historical shared APKs were not recovered.
A new signing key was generated with user authorization, outside this source tree.

Runtime status: the emulator repeatedly lost system services. The final test
harness installation failed with a PackageManager broken pipe. No application
functional checks ran. See STATUS.json and tests/environment-*.txt.

## Installation identities

- Old export21: `com.example.yinqishe_export` (untouched).
- New queue owner: `com.example.yinqishe_shared`.
- New 51 client: `com.xjmb.autilssekoakykiskslsheapp.shared`.

Both new APKs must be installed for the initial deployment. They have independent
identities and can coexist with their old counterparts. Future clients use the
same certificate and protocol; compatible clients need only their own installation,
without reinstalling existing clients or the queue owner.

Do not uninstall or clear the old app to install this build. Runtime validation is
not complete and these files are not a published release.

## Design

X2 owns the encrypted queue, foreground service, persisted SAF folder grant,
parallelism, controls, library, thumbnails, appearance settings, and local playback
progress. A signature permission protects both the provider and visible handoff.

Provider: `content://com.example.yinqishe_shared.shared-download`
Permission: `org.x2.shared.permission.DOWNLOAD` (signature).
`call("protocol")` returns protocol 1. `call("enqueue", null, bundle)` takes
`protocol=1`, `url`, `title`, `userAgent`, `referrer`, and `headers` (complete
`Name: value` strings). Only HTTP(S) inputs and bounded, newline-free headers are
accepted. Responses distinguish `ok`, `need_folder`, and `error`.
`call("status")` returns queue metadata without source URLs or request credentials.
The explicit `org.x2.export.SharedDownloadActivity` performs visible directory
setup or common management; it requires the same signature permission.

51 read-only hooks register lifecycle callbacks, observe the original
`BaseVideoView.setUrl(String, Map)` and `PlayerVideoController.setTitle(String)`,
and never rewrite their arguments, original endpoints, native libraries, or assets.
The client has no independent download queue or file access grant.

## Existing video files

Select the old save folder in the new owner's download settings, then use
“导入此目录已有视频（保留旧文件）”. This adds document references and list entries;
it neither moves files nor changes the old app's database. Reimport is idempotent
by document URI. The existing preview, multiselect, and explicit deletion controls
also apply to imported files. Deleting a shared physical file affects any app
using that file; deleting only its new record leaves the file intact.

The old private queue uses an Android Keystore key and cannot be migrated solely
from APKs. Old MP4 files do not establish the original source URL or fingerprint.
Imported entries explicitly mark that source identity as unknown. Therefore old
imports cannot be promised source-based duplicate rejection before the first new
submission. New submissions from every compatible client share the same source
fingerprints and the same queue, including after completion and process restarts.

Custom settings may be reconfigured in the new installation; no claim is made that
old private settings or playback progress were extracted.

## Build and verification

`python3 build.py` uses verified original APKs, recovered export21 source, ECJ,
Android SDK build tools and Apktool. It changes Java/manifest integration only;
it does not run the old native patcher or install a replacement signing key on
an existing app. Optional old local permission/entry experiment controls were
removed and their runtime flags remain disabled. Account and video permissions
are outside this task.

`python3 tests/audit_apks.py` compares original class coverage and every native
library and asset, and rejects test classes in production APKs.

`python3 tests/build_tests.py` creates a separate test harness and `51-test-only.apk`.
The latter contains a restricted synthetic fixture Activity that calls the real
patched BaseVideoView API. Neither this variant nor harness.apk may be distributed
as the final application. Test media comes from local FFmpeg-generated patterns
and tones; no external video account or protected source is required.

`python3 tests/server.py` serves fixtures with required synthetic headers.
`python3 tests/run_checks.py` exercises fresh jobs, paired dragging, process exit,
common history, duplicate rejection and local playback progress, writing a unique
run directory. Polling uses a separate instrumented client so it does not stop
the owner service. Owner instrumentation is used only before/after downloads.

An x86_64 emulator with ARM64 native translation is a compatibility test, not a
Redmi Turbo4 Pro or a real ARM64 device. Synthetic player-hook tests are separate
from normal real-app startup and real source availability. Do not infer one from
the other. Check logs and result files before claiming any check passed.

## Signing and publication

Never add private keys, password files, APK input dumps, build outputs, or ambient
credentials to Git. Preserve the new private key securely for future clients.
Production APKs have no test fixture entry points. Upload only after functional
checks finish, then download the uploaded files and compare hashes before giving
links. No such publication has been completed.
