#!/usr/bin/env python3
"""Rebuilds Java-only shared download integration from verified export21 and original 51 APK.
Never invokes the old native patcher or changes original source endpoints.
Production signing key stays outside this source tree. Test fixtures are separate APK variants.
"""
from pathlib import Path
import shutil,subprocess,hashlib,xml.etree.ElementTree as E,os,json,secrets
ROOT=Path(__file__).resolve().parent;TOOLS=Path('/workspace/android-tools');SDK=TOOLS/'sdk';BUILD=ROOT/'build';OUT=ROOT/'output';A='{http://schemas.android.com/apk/res/android}'
E.register_namespace('android',A[1:-1])
def run(*args):subprocess.run([str(a) for a in args],check=True)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def compile_dex(name,source,extra=()):
 classes=BUILD/(name+'-classes');dex=BUILD/(name+'-dex');shutil.rmtree(classes,ignore_errors=True);shutil.rmtree(dex,ignore_errors=True);classes.mkdir();dex.mkdir()
 files=sorted(Path(source).rglob('*.java'))
 support=BUILD/'compiler-support';stubs=BUILD/'lambda-stubs';support.mkdir(exist_ok=True);stubs.mkdir(exist_ok=True)
 run('java','-jar',TOOLS/'ecj.jar','-1.8','-proc:none','-d',support,'/workspace/x2-analysis/export-patch/tools/ExtractLambda.java')
 run('java','-cp',support,'ExtractLambda',stubs)
 run('java','-jar',TOOLS/'ecj.jar','-1.8','-proc:none','-nowarn','-bootclasspath',SDK/'android-35/android.jar','-classpath',':'.join(map(str,[stubs,*extra])),'-d',classes,*files)
 jar=BUILD/(name+'.jar')
 import zipfile
 with zipfile.ZipFile(jar,'w') as z:
  for p in classes.rglob('*.class'):z.write(p,p.relative_to(classes))
 run('java','-cp',SDK/'android-15/lib/d8.jar','com.android.tools.r8.D8','--min-api','23','--lib',SDK/'android-35/android.jar','--output',dex,jar)
 return dex/'classes.dex'
def manifest(path,fn):
 t=E.parse(path);fn(t.getroot());t.write(path,encoding='utf-8',xml_declaration=True)
def node(parent,tag,**attrs):return E.SubElement(parent,tag,{A+k:str(v) for k,v in attrs.items()})
def rename_installation(decoded,new_package):
 tree=E.parse(decoded/'AndroidManifest.xml');root=tree.getroot();old=root.get('package');root.set('package',new_package);replacements={}
 for element in root.iter():
  for attr in [A+'authorities',A+'name']:
   value=element.get(attr,'')
   if value.startswith(old+'.') and (attr==A+'authorities' or element.tag in ('permission','uses-permission')):
    replacements[value]=new_package+value[len(old):];element.set(attr,replacements[value])
 tree.write(decoded/'AndroidManifest.xml',encoding='utf-8',xml_declaration=True)
 for folder in decoded.glob('smali*'):
  for path in folder.rglob('*.smali'):
   text=path.read_text();updated=text
   for before,after in replacements.items():updated=updated.replace('"'+before+'"','"'+after+'"')
   if updated!=text:path.write_text(updated)
def prepare_key():
 private=Path('/workspace/shared-download-secrets');private.mkdir(mode=0o700,exist_ok=True);key=private/'shared-download.p12';pw=private/'storepass'
 if not key.exists():
  if not pw.exists():pw.write_text(secrets.token_urlsafe(36)+'\n');pw.chmod(0o600)
  run('keytool','-genkeypair','-storetype','PKCS12','-keystore',key,'-storepass:file',pw,'-keypass:file',pw,'-alias','shared-download','-keyalg','RSA','-keysize','3072','-validity','10000','-dname','CN=Shared Download Local Build, O=Local')
 key.chmod(0o600);return key,pw
def package(name,decoded,key,pw):
 unsigned=BUILD/(name+'-unsigned.apk');aligned=BUILD/(name+'-aligned.apk');final=OUT/(name+'.apk');signed=OUT/(name+'.signing.apk')
 run('java','-jar',TOOLS/'apktool.jar','b',decoded,'-p',TOOLS/'framework','-o',unsigned)
 run(SDK/'android-15/zipalign','-f','-p','4',unsigned,aligned)
 run('java','-jar',TOOLS/'root/usr/share/java/apksigner-35.0.2.jar','sign','--ks',key,'--ks-key-alias','shared-download','--ks-pass','file:'+str(pw),'--v4-signing-enabled','false','--out',signed,aligned)
 run('java','-jar',TOOLS/'root/usr/share/java/apksigner-35.0.2.jar','verify',signed)
 signed.replace(final)
 print(name,sha(final),flush=True);return final
def main():
 BUILD.mkdir(exist_ok=True);OUT.mkdir(exist_ok=True)
 assert sha('/workspace/x2-analysis/input/app.apk')=='c3ec3365df8f01016b0c48db25fd7a1a21bf50bb31ce969d2edddcaf5ea2e385'
 assert sha('/workspace/shebox-analysis/input/app.apk')=='7a7b03df4d26257f2e32741b0809085c90a227c4459e20f8e02842569af2fed1'
 key,pw=prepare_key();engine=BUILD/'x2';client=BUILD/'51'
 for src,dst in [(Path('/workspace/x2-analysis/export21-decoded'),engine),(Path('/workspace/shebox-analysis/decoded'),client)]:
  if dst.exists():shutil.rmtree(dst)
  shutil.copytree(src,dst,ignore=shutil.ignore_patterns('build'))
 rename_installation(engine,'com.example.yinqishe_shared')
 rename_installation(client,'com.xjmb.autilssekoakykiskslsheapp.shared')
 for folder in engine.glob('smali*'):
  p=folder/'org/x2/export'
  if p.exists():shutil.rmtree(p)
 shutil.copy2(compile_dex('engine',ROOT/'src'),engine/'classes4.dex')
 shutil.copy2(compile_dex('client',ROOT/'client'),client/'classes7.dex')
 def patch_engine(root):
  app=root.find('application');node(root,'permission',name='org.x2.shared.permission.DOWNLOAD',protectionLevel='signature');node(root,'uses-permission',name='org.x2.shared.permission.DOWNLOAD')
  node(app,'provider',name='org.x2.export.SharedDownloadGateway',authorities='com.example.yinqishe_shared.shared-download',exported='true',permission='org.x2.shared.permission.DOWNLOAD')
  node(app,'activity',name='org.x2.export.SharedDownloadActivity',exported='true',permission='org.x2.shared.permission.DOWNLOAD',theme='@android:style/Theme.Material.Light.NoActionBar')
  node(app,'activity',name='org.x2.export.LocalPlaybackActivity',exported='false',theme='@android:style/Theme.Material.Light.NoActionBar',configChanges='orientation|screenSize|keyboardHidden')
  app.set(A+'label','X2·共享下载');app.set(A+'debuggable','false')
 def patch_client(root):
  root.find('application').set(A+'label','51盒·共享下载')
  node(root,'uses-permission',name='org.x2.shared.permission.DOWNLOAD');q=root.find('queries')
  if q is None:q=E.SubElement(root,'queries')
  node(q,'package',name='com.example.yinqishe_shared')
 manifest(engine/'AndroidManifest.xml',patch_engine);manifest(client/'AndroidManifest.xml',patch_client)
 # Version metadata lives in apktool.yml, not the decoded manifest.
 import re
 y=engine/'apktool.yml';s=y.read_text();s=re.sub(r'(?m)^  versionCode:.*','  versionCode: 30',s);s=re.sub(r'(?m)^  versionName:.*','  versionName: 9.9.9-shared1',s);y.write_text(s)
 app=client/'smali_classes3/com/lds168app/app/v3/application/MyApplication.smali';s=app.read_text();marker='invoke-super {p0}, Landroid/app/Application;->onCreate()V';assert s.count(marker)==1;s=s.replace(marker,marker+'\n\n    invoke-static {p0}, Lorg/x2/bridge/SourceBridge;->install(Landroid/app/Application;)V');app.write_text(s)
 player=next(client.glob('smali*/xyz/doikki/videoplayer/player/BaseVideoView.smali'));s=player.read_text();marker='    iput-object p2, p0, Lxyz/doikki/videoplayer/player/BaseVideoView;->mHeaders:Ljava/util/Map;';assert s.count(marker)==1;s=s.replace(marker,marker+'\n\n    invoke-static {p0, p1, p2}, Lorg/x2/bridge/SourceBridge;->capture(Landroid/view/View;Ljava/lang/String;Ljava/util/Map;)V');player.write_text(s)
 controller=client/'smali_classes3/com/lds168app/app/v3/player/longs/PlayerVideoController.smali';s=controller.read_text();marker='.method public setTitle(Ljava/lang/String;)V';start=s.index(marker);where=s.index('\n',s.index('.locals ',start));s=s[:where]+s[where:].replace('\n','\n\n    invoke-static {p0, p1}, Lorg/x2/bridge/SourceBridge;->captureTitle(Landroid/view/View;Ljava/lang/String;)V\n',1);controller.write_text(s)
 for name,decoded in [('X2-shared-download',engine),('51-shared-download',client)]:package(name,decoded,key,pw)
 # Audit unchanged source endpoint carriers and native libraries byte-for-byte.
 import zipfile
 for before,after in [('/workspace/shared-download-recovery/X2-export21.apk',OUT/'X2-shared-download.apk'),('/workspace/shebox-analysis/input/app.apk',OUT/'51-shared-download.apk')]:
  with zipfile.ZipFile(before) as b,zipfile.ZipFile(after) as a:
   names=[n for n in b.namelist() if n.startswith(('lib/','assets/')) and not n.endswith('/')]
   assert all(b.read(n)==a.read(n) for n in names),'Original lib/assets changed'
 print('Original libraries and assets preserved byte-for-byte',flush=True)
if __name__=='__main__':main()
