package org.x2.bridge;
import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.net.Uri;
import android.view.View;
import android.widget.*;
import java.util.*;

/** Reusable client contract, with one app-specific read-only player hook. */
public final class SourceBridge implements Application.ActivityLifecycleCallbacks {
 public static final String ENGINE="com.example.yinqishe_shared",AUTHORITY=ENGINE+".shared-download";
 private static final Map<Activity,Bundle> sources=new WeakHashMap<Activity,Bundle>();
 private static final Map<Activity,String> titles=new WeakHashMap<Activity,String>();
 private static boolean installed;
 public static void captureTitle(View view,String title){try{Activity a=activity(view.getContext());if(a!=null&&title!=null&&!title.isEmpty())synchronized(sources){titles.put(a,title);Bundle b=sources.get(a);if(b!=null)b.putString("title",title);}}catch(Throwable ignored){}}
 public static void install(Application app){try{if(!installed){installed=true;app.registerActivityLifecycleCallbacks(new SourceBridge());}}catch(Throwable ignored){}}
 private static Activity activity(Context c){for(int i=0;i<12;i++){if(c instanceof Activity)return (Activity)c;if(!(c instanceof ContextWrapper))break;Context n=((ContextWrapper)c).getBaseContext();if(n==c)break;c=n;}return null;}
 public static void capture(View player,String url,Map<?,?> headers){
  try{
   Activity a=activity(player.getContext());if(a==null)return; synchronized(sources){sources.remove(a);}
   if(url==null||url.isEmpty()){synchronized(sources){sources.remove(a);}return;}
   Uri uri=Uri.parse(url);if(!"http".equalsIgnoreCase(uri.getScheme())&&!"https".equalsIgnoreCase(uri.getScheme()))return;
   Bundle b=new Bundle();b.putInt("protocol",1);b.putString("url",url);b.putString("title",String.valueOf(a.getTitle()));
   ArrayList<String> lines=new ArrayList<String>();
   if(headers!=null)for(Map.Entry<?,?> e:headers.entrySet()){
    if(!(e.getKey() instanceof String)||!(e.getValue() instanceof String))continue;
    String k=(String)e.getKey(),v=(String)e.getValue();lines.add(k+": "+v);
    if("user-agent".equalsIgnoreCase(k))b.putString("userAgent",v);
    if("referer".equalsIgnoreCase(k))b.putString("referrer",v);
   }
   b.putStringArray("headers",lines.toArray(new String[0]));synchronized(sources){if(titles.containsKey(a))b.putString("title",titles.get(a));sources.put(a,b);}
  }catch(Throwable ignored){/* Capture is optional: never change player behavior. */}
 }
 public static void submit(Activity a){
  final Bundle data;synchronized(sources){Bundle value=sources.get(a);data=value==null?null:new Bundle(value);}
  if(data==null){message(a,"请先在当前页面播放视频，再点击下载。");return;}
  new Thread(()->{String status="error",error="共享下载不可用，请先安装同签名的 X2 共享下载版";
   try{Bundle r=a.getContentResolver().call(Uri.parse("content://"+AUTHORITY),"enqueue",null,data);if(r!=null){status=r.getString("status","error");error=r.getString("message",error);}}
   catch(Exception ignored){}
   final String s=status,e=error;a.runOnUiThread(()->{if(a.isFinishing()||a.isDestroyed())return;if("ok".equals(s))Toast.makeText(a,"已加入 X2 共享后台下载",Toast.LENGTH_SHORT).show();else if("need_folder".equals(s))open(a,"enqueue",data);else message(a,e);});
  },"shared-download-submit").start();
 }
 public static void manage(Activity a){open(a,"manage",null);}
 private static void open(Activity a,String operation,Bundle b){try{
  Intent i=new Intent().setComponent(new ComponentName(ENGINE,"org.x2.export.SharedDownloadActivity")).putExtra("operation",operation);if(b!=null)i.putExtras(b);a.startActivity(i);
 }catch(Exception e){message(a,"请先安装同签名的 X2 共享下载版");}}
 private static void message(Activity a,String text){new AlertDialog.Builder(a).setTitle("共享下载").setMessage(text).setPositiveButton("知道了",null).show();}
 public void onActivityResumed(Activity a){if(a.getClass().getName().startsWith("com.lds168app.")||a.getClass().getName().startsWith("org.x2.test."))Overlay.attach(a);}
 public void onActivityCreated(Activity a,Bundle b){}public void onActivityStarted(Activity a){}public void onActivityPaused(Activity a){}public void onActivityStopped(Activity a){}public void onActivitySaveInstanceState(Activity a,Bundle b){}
 public void onActivityDestroyed(Activity a){synchronized(sources){sources.remove(a);titles.remove(a);}}
}
