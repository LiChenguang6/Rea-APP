package org.x2.bridge;
import android.app.Activity;
import android.content.SharedPreferences;
import android.view.*;
import android.widget.*;
/** One horizontal pair; children retain clicks until a true drag exceeds touch slop. */
public final class Overlay extends LinearLayout {
 private final SharedPreferences prefs;private final int slop;private boolean dragging;private float downX,downY,startX,startY;
 private Overlay(Activity a){super(a);prefs=a.getSharedPreferences("shared-download-overlay",0);slop=ViewConfiguration.get(a).getScaledTouchSlop();setOrientation(HORIZONTAL);setTag("shared-download-buttons");setContentDescription("下载与管理，可拖动");setMotionEventSplittingEnabled(false);
  for(String text:new String[]{"下载","管理"}){Button button=new Button(a);button.setText(text);button.setTextSize(12);button.setTextColor(0xffffffff);button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xdd395a85));addView(button,new LinearLayout.LayoutParams(0,-1,1));button.setOnClickListener(v->{if("下载".equals(text))SourceBridge.submit(a);else SourceBridge.manage(a);});}
  addOnLayoutChangeListener((v,l,t,r,b,ol,ot,or,ob)->{if(!dragging)restore();});
 }
 public static void attach(Activity a){try{ViewGroup root=a.findViewById(android.R.id.content);if(root==null||root.findViewWithTag("shared-download-buttons")!=null)return;Overlay row=new Overlay(a);float d=a.getResources().getDisplayMetrics().density;FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(Math.round(152*d),Math.round(44*d),Gravity.TOP|Gravity.RIGHT);p.topMargin=Math.round(80*d);p.rightMargin=Math.round(8*d);a.addContentView(row,p);row.post(row::restore);}catch(Throwable ignored){}}
 private float maxX(){return getParent() instanceof View?Math.max(0,((View)getParent()).getWidth()-getWidth()):0;}private float maxY(){return getParent() instanceof View?Math.max(0,((View)getParent()).getHeight()-getHeight()):0;}
 private static float clamp(float v,float max){return Math.max(0,Math.min(v,max));}
 private void restore(){if(prefs.contains("x")){setX(clamp(prefs.getFloat("x",1)*maxX(),maxX()));setY(clamp(prefs.getFloat("y",0)*maxY(),maxY()));}}
 private void move(MotionEvent e){setX(clamp(startX+e.getRawX()-downX,maxX()));setY(clamp(startY+e.getRawY()-downY,maxY()));}
 public boolean onInterceptTouchEvent(MotionEvent e){if(e.getActionMasked()==MotionEvent.ACTION_DOWN){dragging=false;downX=e.getRawX();downY=e.getRawY();startX=getX();startY=getY();}else if(e.getActionMasked()==MotionEvent.ACTION_MOVE&&Math.hypot(e.getRawX()-downX,e.getRawY()-downY)>slop){dragging=true;getParent().requestDisallowInterceptTouchEvent(true);move(e);return true;}return dragging;}
 public boolean onTouchEvent(MotionEvent e){if(!dragging)return super.onTouchEvent(e);move(e);if(e.getActionMasked()==MotionEvent.ACTION_UP||e.getActionMasked()==MotionEvent.ACTION_CANCEL){prefs.edit().putFloat("x",maxX()==0?0:getX()/maxX()).putFloat("y",maxY()==0?0:getY()/maxY()).commit();dragging=false;}return true;}
}
