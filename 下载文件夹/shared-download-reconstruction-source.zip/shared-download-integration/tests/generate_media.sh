#!/bin/bash
set -euo pipefail
fixture_root=/workspace/shared-download-integration/tests/media
mkdir -p "$fixture_root"
ffmpeg -y -hide_banner -loglevel error -f lavfi -i 'testsrc2=size=320x180:rate=15' -f lavfi -i 'sine=frequency=440:sample_rate=44100' -t 35 -c:v libx264 -preset ultrafast -b:v 700k -g 15 -c:a aac -movflags +faststart "$fixture_root/fixture.mp4"
