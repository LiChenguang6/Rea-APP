package org.x2.export;
import android.app.*;import android.os.*;import android.content.*;import android.net.Uri;import android.widget.VideoView;import org.json.*;
/** Test-only instrumentation; never packaged in distributable APKs. */
public final class Runner extends Instrumentation {
 private Bundle args;public void onCreate(Bundle b){args=b;start();}
 public void onStart(){Bundle result=new Bundle();try{String operation=args.getString("operation","snapshot");Context c=getTargetContext();
  if("configure".equals(operation)){
   DownloadConfig.setFolder(c,Uri.parse("content://org.x2.shared.tests.documents/tree/root"),Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
   DownloadConfig.setParallel(c,2);DownloadConfig.setColumns(c,2);DownloadConfig.setPreviews(c,true);
  }else if("import".equals(operation)){result.putInt("imported",LocalLibrary.scan(c));
  }else if("play".equals(operation)){
   DownloadStore.Job j=DownloadStore.get(c).find(args.getString("id"));if(j==null||!j.state.equals("success"))throw new Exception("missing completed job");
   Intent i=new Intent(c,LocalPlaybackActivity.class).putExtra("jobId",j.id).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
   final Activity a=startActivitySync(i);long until=SystemClock.uptimeMillis()+60000;
   while(SystemClock.uptimeMillis()<until){final boolean[] ok={false};runOnMainSync(()->{VideoView v=(VideoView)((android.view.ViewGroup)a.findViewById(android.R.id.content)).getChildAt(0);ok[0]=v.getDuration()>0;});if(ok[0])break;SystemClock.sleep(200);}
   final int[] duration={0};runOnMainSync(()->{VideoView v=(VideoView)((android.view.ViewGroup)a.findViewById(android.R.id.content)).getChildAt(0);duration[0]=v.getDuration();v.seekTo(12000);v.start();});if(duration[0]<=15000)throw new Exception("fixture not prepared");
   SystemClock.sleep(3000);runOnMainSync(()->a.finish());SystemClock.sleep(1000);int pos=c.getSharedPreferences("x2-local-playback",0).getInt(j.id,0);if(pos<11000)throw new Exception("progress not saved: "+pos);result.putInt("savedPosition",pos);
  }else if("resume".equals(operation)){
   String id=args.getString("id");int saved=c.getSharedPreferences("x2-local-playback",0).getInt(id,0);if(saved<11000)throw new Exception("missing persisted progress");
   Activity a=startActivitySync(new Intent(c,LocalPlaybackActivity.class).putExtra("jobId",id).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));int[] position={0};long until=SystemClock.uptimeMillis()+60000;
   while(SystemClock.uptimeMillis()<until){runOnMainSync(()->{VideoView v=(VideoView)((android.view.ViewGroup)a.findViewById(android.R.id.content)).getChildAt(0);position[0]=v.getCurrentPosition();});if(position[0]>=saved-1500)break;SystemClock.sleep(200);}
   runOnMainSync(()->a.finish());if(position[0]<saved-1500)throw new Exception("resume position wrong");result.putInt("resumedPosition",position[0]);
  }
  JSONArray jobs=new JSONArray();for(DownloadStore.Job j:DownloadStore.get(c).all()){JSONObject row=new JSONObject();row.put("id",j.id);row.put("state",j.state);row.put("title",j.title);row.put("progress",j.progress);row.put("document",j.document);row.put("stage",j.stage);jobs.put(row);}
  result.putString("jobs",jobs.toString());result.putInt("parallel",DownloadConfig.parallel(c));result.putInt("columns",DownloadConfig.columns(c));result.putBoolean("previews",DownloadConfig.previews(c));result.putString("folder",DownloadConfig.folder(c));result.putString("outcome","passed");finish(Activity.RESULT_OK,result);
 }catch(Throwable e){result.putString("outcome","failed");result.putString("failure",e.toString());finish(Activity.RESULT_CANCELED,result);}}
}
