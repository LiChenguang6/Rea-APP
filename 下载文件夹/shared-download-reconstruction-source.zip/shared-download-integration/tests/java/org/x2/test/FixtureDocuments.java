package org.x2.test;
import android.provider.*;
import android.database.*;
import android.os.*;
import java.io.*;
/** Test-only SAF provider; each instrumentation run receives a fresh directory. */
public final class FixtureDocuments extends DocumentsProvider {
 public boolean onCreate(){return true;}
 private File directory(){File f=new File(getContext().getFilesDir(),"documents");f.mkdirs();return f;}
 private File file(String id)throws FileNotFoundException {if("root".equals(id))return directory();if(!id.matches("[a-zA-Z0-9_.-]+"))throw new FileNotFoundException();return new File(directory(),id);}
 private String[] columns(String[] p){return p==null?new String[]{"document_id","_display_name","mime_type","flags","_size"}:p;}
 private void row(MatrixCursor c,String id,File f){MatrixCursor.RowBuilder r=c.newRow();for(String col:c.getColumnNames()){
  Object v=null;if(col.equals("document_id"))v=id;else if(col.equals("_display_name"))v=id.equals("root")?"Shared Test":f.getName();else if(col.equals("mime_type"))v=id.equals("root")?DocumentsContract.Document.MIME_TYPE_DIR:"video/mp4";else if(col.equals("flags"))v=id.equals("root")?DocumentsContract.Document.FLAG_DIR_SUPPORTS_CREATE:DocumentsContract.Document.FLAG_SUPPORTS_WRITE|DocumentsContract.Document.FLAG_SUPPORTS_DELETE;else if(col.equals("_size"))v=f.length();r.add(v);
 }}
 public Cursor queryRoots(String[] p){MatrixCursor c=new MatrixCursor(new String[]{"root_id","document_id","title","flags"});c.addRow(new Object[]{"root","root","Shared Test",3});return c;}
 public Cursor queryDocument(String id,String[] p)throws FileNotFoundException{MatrixCursor c=new MatrixCursor(columns(p));row(c,id,file(id));return c;}
 public Cursor queryChildDocuments(String parent,String[] p,String sort)throws FileNotFoundException{MatrixCursor c=new MatrixCursor(columns(p));for(File f:directory().listFiles())row(c,f.getName(),f);return c;}
 public ParcelFileDescriptor openDocument(String id,String mode,CancellationSignal cancel)throws FileNotFoundException{return ParcelFileDescriptor.open(file(id),ParcelFileDescriptor.parseMode(mode));}
 public String createDocument(String parent,String mime,String name)throws FileNotFoundException{String safe=name.replaceAll("[^a-zA-Z0-9_.-]","_");if(safe.isEmpty())safe="video.mp4";File f=file(safe);int n=0;while(f.exists())f=file((++n)+"_"+safe);try{if(!f.createNewFile())throw new IOException();}catch(IOException e){throw new FileNotFoundException();}return f.getName();}
 public void deleteDocument(String id)throws FileNotFoundException{if(!file(id).delete())throw new FileNotFoundException();}
 public Bundle call(String method,String arg,Bundle extras){
  if(!"seedLegacy".equals(method)&&!"hashes".equals(method))return super.call(method,arg,extras);
  Bundle out=new Bundle();try{
   if("seedLegacy".equals(method)){File[] entries=directory().listFiles();if(entries.length==0)throw new IOException("no completed fixture");File target=new File(directory(),"legacy.mp4");try(FileInputStream in=new FileInputStream(entries[0]);FileOutputStream f=new FileOutputStream(target)){byte[] data=new byte[8192];int n;while((n=in.read(data))!=-1)f.write(data,0,n);}}
   org.json.JSONObject hashes=new org.json.JSONObject();for(File f:directory().listFiles()){java.security.MessageDigest md=java.security.MessageDigest.getInstance("SHA-256");try(FileInputStream in=new FileInputStream(f)){byte[] data=new byte[8192];int n;while((n=in.read(data))!=-1)md.update(data,0,n);}StringBuilder h=new StringBuilder();for(byte b:md.digest())h.append(String.format("%02x",b));hashes.put(f.getName(),h.toString());}out.putString("hashes",hashes.toString());out.putString("status","ok");
  }catch(Exception e){out.putString("status","error");out.putString("message",e.toString());}return out;
 }
 public boolean isChildDocument(String parent,String child){return "root".equals(parent)&&!"root".equals(child);}
}
