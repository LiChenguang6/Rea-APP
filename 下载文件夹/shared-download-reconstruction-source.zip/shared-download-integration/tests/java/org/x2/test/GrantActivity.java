package org.x2.test;
import android.app.*;import android.content.*;import android.net.Uri;import android.os.Bundle;
public final class GrantActivity extends Activity {public void onCreate(Bundle b){super.onCreate(b);grantUriPermission("com.example.yinqishe_shared",Uri.parse("content://org.x2.shared.tests.documents/tree/root"),Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION|Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);finish();}}
