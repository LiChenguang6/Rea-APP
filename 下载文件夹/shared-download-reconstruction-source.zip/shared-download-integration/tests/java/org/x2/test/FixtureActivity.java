package org.x2.test;
import android.app.*;import android.os.Bundle;import android.widget.*;import android.view.*;import org.x2.bridge.SourceBridge;import java.util.*;
/** Added only to a test copy of 51; calls its actual patched BaseVideoView.setUrl. */
public final class FixtureActivity extends Activity {
 public void onCreate(Bundle b){super.onCreate(b);setTitle("Synthetic shared download fixture");LinearLayout root=new LinearLayout(this);root.setOrientation(1);setContentView(root);TextView t=new TextView(this);t.setText("Synthetic nonsexual media fixture");root.addView(t);
  try{String url=getIntent().getStringExtra("url");if(url==null||!url.startsWith("http://10.0.2.2:8765/"))throw new IllegalArgumentException("test server only");
   Class<?> type=Class.forName("xyz.doikki.videoplayer.player.VideoView");Object player=type.getConstructor(android.content.Context.class).newInstance(this);root.addView((View)player,new LinearLayout.LayoutParams(-1,300));Map<String,String> headers=new LinkedHashMap<String,String>();headers.put("User-Agent","SharedDownloadFixture/1");headers.put("Referer","https://fixture.invalid/player");headers.put("X-Fixture-Token","synthetic-only");type.getMethod("setUrl",String.class,Map.class).invoke(player,url,headers);
  }catch(Throwable e){t.setText("Fixture error: "+e.getClass().getName());}
 }
}
