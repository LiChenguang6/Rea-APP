package org.x2.test;
import android.app.*;import android.os.Bundle;import android.net.Uri;
/** Queries from a separate process so observing progress never stops the download service. */
public final class ClientRunner extends Instrumentation {
 private String operation;public void onCreate(Bundle b){operation=b.getString("operation","snapshot");start();}
 public void onStart(){Bundle result=new Bundle();try{
  Bundle state=getContext().getContentResolver().call(Uri.parse(("seedLegacy".equals(operation)||"hashes".equals(operation))?"content://org.x2.shared.tests.documents":"content://com.example.yinqishe_shared.shared-download"),"snapshot".equals(operation)?"status":operation,null,null);
  if(state==null||!"ok".equals(state.getString("status")))throw new Exception("status unavailable");result.putAll(state);result.putString("outcome","passed");finish(Activity.RESULT_OK,result);
 }catch(Throwable e){result.putString("outcome","failed");result.putString("failure",e.toString());finish(Activity.RESULT_CANCELED,result);}}
}
