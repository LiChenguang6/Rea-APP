"""Real emulator checks. Never treats an old job or an open port as a passed download."""
from pathlib import Path
import subprocess,json,time,re,xml.etree.ElementTree as E,uuid
R=Path(__file__).parent;ADB='/workspace/android-tools/sdk/platform-tools/adb';PKG='com.xjmb.autilssekoakykiskslsheapp.shared';ENGINE='com.example.yinqishe_shared';RUN=uuid.uuid4().hex;RESULT={'run':RUN,'checks':[]};LOG=R/('run-'+RUN);LOG.mkdir()
def cmd(*a,timeout=180):
 p=subprocess.run([ADB,*a],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=timeout)
 if p.returncode:raise RuntimeError(p.stdout[-3000:])
 return p.stdout

def check(name,fn):
 try:value=fn();RESULT['checks'].append({'name':name,'outcome':'passed','evidence':value});print('PASS',name,flush=True)
 except Exception as e:
  RESULT['checks'].append({'name':name,'outcome':'failed','reason':str(e)});print('FAIL',name,str(e),flush=True);raise
 finally:(LOG/'results.json').write_text(json.dumps(RESULT,indent=2)+'\n')
def runner(op,**args):
 a=['shell','am','instrument','-w','-r','-e','operation',op]
 for k,v in args.items():a+=['-e',k,str(v)]
 a+=['org.x2.shared.tests/'+('org.x2.test.ClientRunner' if op in ('snapshot','seedLegacy','hashes') else 'org.x2.export.Runner')];s=cmd(*a,timeout=240);(LOG/(op+'-'+str(time.time_ns())+'.txt')).write_text(s)
 if 'outcome=passed' not in s:raise RuntimeError(s[-3000:])
 out={}
 for line in s.splitlines():
  if line.startswith('INSTRUMENTATION_RESULT: '):
   k,_,v=line[24:].partition('=');out[k]=v
 if 'jobs' in out:out['jobs']=json.loads(out['jobs'])
 return out

def dump():
 cmd('shell','uiautomator','dump','/sdcard/shared-window.xml',timeout=120)
 s=cmd('exec-out','cat','/sdcard/shared-window.xml');return E.fromstring(s)
def bounds(node):return list(map(int,re.findall(r'\d+',node.attrib['bounds'])))
def center(b):return ((b[0]+b[2])//2,(b[1]+b[3])//2)
def node_by_text(text):
 tree=dump()
 for n in tree.iter('node'):
  if n.get('text')==text:return n
 raise RuntimeError('UI missing '+text)
def tap(text):cmd('shell','input','tap',*map(str,center(bounds(node_by_text(text)))))
def fixture(label):
 cmd('shell','am','start','-W','-n',PKG+'/org.x2.test.FixtureActivity','--es','url','http://10.0.2.2:8765/'+RUN+'/'+label+'.mp4',timeout=240)
 until=time.monotonic()+90
 while time.monotonic()<until:
  try:return bounds(node_by_text('下载'))
  except Exception:time.sleep(1)
 raise RuntimeError('fixture overlay not ready')
def wait_jobs(ids):
 until=time.monotonic()+240
 while time.monotonic()<until:
  snapshot=runner('snapshot');jobs={j['id']:j for j in snapshot['jobs']}
  if all(jobs.get(i,{}).get('state')=='success' for i in ids):return snapshot
  if any(jobs.get(i,{}).get('state')=='failed' for i in ids):raise RuntimeError(str(snapshot))
  time.sleep(2)
 raise RuntimeError('fresh downloads did not complete')

def main():
 print('RUN',RUN,flush=True)
 check('old and new X2 coexist',lambda:all('package:'+name in cmd('shell','pm','list','packages').splitlines() for name in ['com.example.yinqishe_export',ENGINE]) or (_ for _ in ()).throw(Exception('both packages not installed')))
 cmd('shell','am','start','-W','-n','org.x2.shared.tests/org.x2.test.GrantActivity')
 check('shared SAF configuration',lambda:runner('configure'))
 before=runner('snapshot')['jobs'];assert before==[],before
 check('fresh queue baseline',lambda:{'jobs':len(before)})
 b=fixture('one');x,y=center(b);cmd('shell','input','swipe',str(x),str(y),str(x-100),str(y+140),'900');new=bounds(node_by_text('下载'))
 check('drag changes paired button position',lambda:{'before':b,'after':new} if abs(new[0]-b[0])>60 and abs(new[1]-b[1])>80 else (_ for _ in ()).throw(Exception(str([b,new]))))
 m=bounds(node_by_text('管理'));check('buttons remain side by side',lambda: {'download':new,'manage':m} if abs(new[1]-m[1])<5 and m[0]>=new[2]-5 else (_ for _ in ()).throw(Exception('buttons not parallel')))
 cmd('shell','am','force-stop',PKG);after=fixture('one');check('drag position survives client process restart',lambda:after if max(abs(a-b) for a,b in zip(after,new))<8 else (_ for _ in ()).throw(Exception(str([new,after]))))
 tap('下载');time.sleep(1);one=runner('snapshot')['jobs'];assert len(one)==1,one;first=one[0]['id']
 fixture('two');tap('下载');time.sleep(1);two=runner('snapshot')['jobs'];assert len(two)==2,two;ids=[j['id'] for j in two];assert any(j['state'] in ('running','queued') for j in two), 'downloads already finished before client exit; background check invalid'
 check('two distinct fresh submissions',lambda:{'ids':ids,'all_new':not(set(ids)&{j['id'] for j in before})})
 cmd('shell','am','force-stop',PKG);cmd('shell','input','keyevent','KEYCODE_HOME')
 done=wait_jobs(ids);check('both fresh downloads complete after client exit',lambda:done)
 fixture('one');tap('下载');time.sleep(1);now=runner('snapshot')['jobs'];check('duplicate source rejected across client restart',lambda:{'before':len(done['jobs']),'after':len(now)} if len(now)==2 else (_ for _ in ()).throw(Exception('duplicate queued')))
 tap('知道了');tap('管理');tree=dump();xml=E.tostring(tree,encoding='unicode');check('client opens common X2 management',lambda:ENGINE if ENGINE in xml else (_ for _ in ()).throw(Exception(xml[:800])))
 check('local playback stores progress',lambda:runner('play',id=first))
 cmd('shell','am','force-stop',ENGINE)
 check('local playback resumes after engine process restart',lambda:runner('resume',id=first))
 persisted=runner('snapshot');check('queue and custom preview settings survive process restart',lambda:persisted if len(persisted['jobs'])==2 and persisted['parallel']=='2' and persisted['columns']=='2' else (_ for _ in ()).throw(Exception(str(persisted))))
 hashes=runner('seedLegacy')['hashes']
 imported=runner('import');check('existing local video import',lambda:imported if imported['imported']=='1' else (_ for _ in ()).throw(Exception(str(imported))))
 again=runner('import');check('reimport does not duplicate records',lambda:again if again['imported']=='0' else (_ for _ in ()).throw(Exception(str(again))))
 after_hashes=runner('hashes')['hashes'];check('import preserves existing video bytes',lambda:hashes if hashes==after_hashes else (_ for _ in ()).throw(Exception('file bytes changed')))
 print('Completed checks:',len(RESULT['checks']),flush=True)
if __name__=='__main__':main()
