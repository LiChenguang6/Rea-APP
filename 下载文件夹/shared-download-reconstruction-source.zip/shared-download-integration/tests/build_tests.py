from pathlib import Path
import sys,shutil,zipfile,xml.etree.ElementTree as E
sys.path.insert(0,str(Path(__file__).resolve().parents[1]));import build as b
r=b.ROOT;out=r/'tests/artifacts';out.mkdir(exist_ok=True)
dex=b.compile_dex('tests',r/'tests/java',[b.BUILD/'engine.jar',b.BUILD/'client.jar'])
manifest='''<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="org.x2.shared.tests"><uses-sdk android:minSdkVersion="23" android:targetSdkVersion="28"/><uses-permission android:name="org.x2.shared.permission.DOWNLOAD"/><application android:label="Shared Download Test Fixtures" android:usesCleartextTraffic="true"><provider android:name="org.x2.test.FixtureDocuments" android:authorities="org.x2.shared.tests.documents" android:exported="true" android:grantUriPermissions="true" android:permission="org.x2.shared.permission.DOWNLOAD"/><activity android:name="org.x2.test.GrantActivity" android:exported="true"/></application><instrumentation android:name="org.x2.export.Runner" android:targetPackage="com.example.yinqishe_shared"/><instrumentation android:name="org.x2.test.ClientRunner" android:targetPackage="org.x2.shared.tests"/></manifest>'''
p=out/'AndroidManifest.xml';p.write_text(manifest);unsigned=out/'harness-unsigned.apk'
b.run(b.SDK/'android-15/aapt2','link','-I',b.SDK/'android-35/android.jar','--manifest',p,'-o',unsigned)
with zipfile.ZipFile(unsigned,'a') as z:z.write(dex,'classes.dex')
key,pw=b.prepare_key();aligned=out/'harness-aligned.apk';b.run(b.SDK/'android-15/zipalign','-f','4',unsigned,aligned)
b.run('java','-jar',b.TOOLS/'root/usr/share/java/apksigner-35.0.2.jar','sign','--ks',key,'--ks-key-alias','shared-download','--ks-pass','file:'+str(pw),'--out',out/'harness.apk',aligned)
if '--harness-only' in sys.argv:sys.exit(0)
test51=b.BUILD/'51-test';shutil.rmtree(test51,ignore_errors=True);shutil.copytree(b.BUILD/'51',test51,ignore=shutil.ignore_patterns('build'))
shutil.copy2(dex,test51/'classes8.dex')
b.manifest(test51/'AndroidManifest.xml',lambda root:b.node(root.find('application'),'activity',name='org.x2.test.FixtureActivity',exported='true',theme='@android:style/Theme.Material.Light.NoActionBar'))
b.package('51-test-only',test51,key,pw)
print('TEST FIXTURES ONLY; never publish 51-test-only or harness.apk')
