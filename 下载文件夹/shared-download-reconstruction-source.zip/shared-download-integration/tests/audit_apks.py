import struct,zipfile,hashlib,json
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def classes(apk):
 names=set()
 with zipfile.ZipFile(apk) as z:
  for n in z.namelist():
   if not (n.startswith('classes') and n.endswith('.dex')):continue
   b=z.read(n)
   def u(off):return struct.unpack_from('<I',b,off)[0]
   strings=u(60);types=u(68);count=u(96);definitions=u(100)
   for i in range(count):
    idx=u(definitions+i*32);stringidx=u(types+idx*4);off=u(strings+stringidx*4)
    while b[off]&128:off+=1
    off+=1;end=b.index(0,off);names.add(b[off:end].decode('utf-8'))
 return names
report=[]
for original,new in [('/workspace/shared-download-recovery/X2-export21.apk',R/'output/X2-shared-download.apk'),('/workspace/shebox-analysis/input/app.apk',R/'output/51-shared-download.apk')]:
 old=classes(original);now=classes(new);missing=old-now
 if 'X2-' in str(new):missing={n for n in missing if not n.startswith('Lorg/x2/export/')}
 assert not missing,sorted(missing)[:25]
 with zipfile.ZipFile(original) as before,zipfile.ZipFile(new) as after:
  preserved=[n for n in before.namelist() if n.startswith(('assets/','lib/')) and not n.endswith('/')]
  assert all(before.read(n)==after.read(n) for n in preserved)
  assert 'classes7.dex' in after.namelist() if '51-' in str(new) else 'classes4.dex' in after.namelist()
  # Production must never contain fixture or instrumentation classes.
  assert not any(n.startswith('Lorg/x2/test/') or n=='Lorg/x2/export/Runner;' for n in now)
 report.append({'file':new.name,'sha256':hashlib.sha256(new.read_bytes()).hexdigest(),'original_classes':len(old),'candidate_classes':len(now),'missing_original_classes':len(missing),'unchanged_asset_and_native_files':len(preserved),'test_classes_present':False})
(R/'tests/artifact-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
