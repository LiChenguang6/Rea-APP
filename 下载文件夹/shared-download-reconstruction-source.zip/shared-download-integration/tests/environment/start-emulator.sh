#!/bin/bash
set -euo pipefail
export ANDROID_SDK_ROOT=/workspace/android-tools/sdk
export ANDROID_AVD_HOME=/workspace/android-lab/avd
export ANDROID_USER_HOME=/workspace/android-lab/user
export ANDROID_EMULATOR_HOME=/workspace/android-lab/user
exec /workspace/android-tools/sdk/emulator/emulator -avd lab -no-window -no-audio -no-boot-anim -no-snapshot -accel off -gpu swiftshader_indirect -camera-back none -camera-front none -cores 2 -memory 6144 -skin 480x800 -dpi-device 160 -prop ro.hw_timeout_multiplier=10
