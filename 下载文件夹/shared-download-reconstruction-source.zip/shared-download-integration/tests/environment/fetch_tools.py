from pathlib import Path
import urllib.request as U, xml.etree.ElementTree as E, hashlib, zipfile, concurrent.futures,os
base=Path('/workspace/android-tools'); sdk=base/'sdk'; sdk.mkdir(exist_ok=True)
jobs=[]
for filename,wanted,prefix,target in [
 ('repository.xml',{'platforms;android-35','build-tools;35.0.0','emulator','platform-tools'},'https://dl.google.com/android/repository/',sdk),
 ('system-images.xml',{'system-images;android-30;google_apis;x86_64'},'https://dl.google.com/android/repository/sys-img/google_apis/',sdk/'system-images/android-30/google_apis')]:
 seen=set()
 for p in E.parse(base/filename).getroot():
  name=p.attrib.get('path')
  if name not in wanted or name in seen:continue
  if p.find('channelRef') is not None and p.find('channelRef').get('ref')!='channel-0':continue
  for a in p.findall('archives/archive'):
   if a.findtext('host-os') not in (None,'linux'): continue
   c=a.find('complete'); jobs.append((name,prefix+c.findtext('url'),c.find('checksum').get('type','sha1'),c.findtext('checksum'),target)); seen.add(name);break

def one(j):
 name,url,alg,expected,target=j; dest=base/url.rsplit('/',1)[1]; temp=dest.with_suffix('.partial')
 if not dest.exists():
  print('DOWNLOAD',name,flush=True)
  with U.urlopen(url,timeout=90) as r,temp.open('wb') as f:
   while block:=r.read(1024*1024):f.write(block)
  temp.replace(dest)
 h=hashlib.new(alg)
 with dest.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 if h.hexdigest()!=expected:raise ValueError('Checksum mismatch '+name)
 print('VERIFIED',name,flush=True)
 with zipfile.ZipFile(dest) as z:
  for i in z.infolist():
   out=(target/i.filename).resolve()
   if not out.is_relative_to(target.resolve()):raise ValueError(i.filename)
   z.extract(i,target)
   if i.external_attr>>16&0o111:out.chmod(0o755)
 print('READY',name,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(one,jobs))
