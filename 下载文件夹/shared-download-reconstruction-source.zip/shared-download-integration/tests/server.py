import http.server,time,json,threading
from pathlib import Path
ROOT=Path(__file__).parent;MEDIA=(ROOT/'media/fixture.mp4').read_bytes();LOG=ROOT/'requests.jsonl'
class Handler(http.server.BaseHTTPRequestHandler):
 def log_message(self,*a):pass
 def do_GET(self):
  valid=(self.headers.get('User-Agent')=='SharedDownloadFixture/1' and self.headers.get('Referer')=='https://fixture.invalid/player' and self.headers.get('X-Fixture-Token')=='synthetic-only')
  LOG.open('a').write(json.dumps({'time':time.time(),'path':self.path,'required_headers_received':valid})+'\n')
  if not valid:self.send_error(403);return
  self.send_response(200);self.send_header('Content-Type','video/mp4');self.send_header('Content-Length',str(len(MEDIA)));self.end_headers()
  try:
   for i in range(0,len(MEDIA),32768):self.wfile.write(MEDIA[i:i+32768]);self.wfile.flush();time.sleep(.5)
  except (BrokenPipeError,ConnectionResetError):pass
http.server.ThreadingHTTPServer(('127.0.0.1',8765),Handler).serve_forever()
